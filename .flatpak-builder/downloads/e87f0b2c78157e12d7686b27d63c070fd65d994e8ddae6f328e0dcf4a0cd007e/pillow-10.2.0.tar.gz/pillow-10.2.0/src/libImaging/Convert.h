extern void
cmyk2rgb(UINT8 *out, const UINT8 *in, int xsize);
